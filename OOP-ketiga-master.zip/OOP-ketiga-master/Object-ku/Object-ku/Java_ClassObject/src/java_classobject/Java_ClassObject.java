/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_classobject;

/**
 *
 * @author windows
 */
public class Java_ClassObject {
  int x = 5;

  public static void main(String[] args) {
    Java_ClassObject myObj = new Java_ClassObject();
    System.out.println(myObj.x);
  }
}
    