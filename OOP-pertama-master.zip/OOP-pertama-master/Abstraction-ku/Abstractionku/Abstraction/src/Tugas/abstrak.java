/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas;

/**
 *
 * @author windows
 */
public class abstrak {
     public static void main(String[] args) {
    laki_laki s = new laki_laki(); // Create a Pig object
    perempuan p = new perempuan();
    s.suaramanusia();
    s.tidur();
    p.suaramanusia();
    p.tidur();
  }
}
