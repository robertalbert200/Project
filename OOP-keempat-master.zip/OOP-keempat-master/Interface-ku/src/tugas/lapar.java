/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas;

/**
 *
 * @author windows
 */
class lapar implements makan, minum {
     public void Ma() {
    System.out.println("Saya Makan");
  }
  public void Mi() {
    System.out.println("Saya Minum");
  }
}

